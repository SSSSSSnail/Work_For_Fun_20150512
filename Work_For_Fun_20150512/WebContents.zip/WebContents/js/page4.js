$(document).ready(function() {
    $("#page4_bg").css({
		"width": "1024px",
		"height": "748px",
		"background": "url(\'images/page4_bg.png\') no-repeat",
		"background-size": "1024px 748px"
	})
      
	$.getScript("js/common.js", function() {
		addComment("文献：<br/>6.Ploussard G, Mongiat-Artus P. Future Oncol. 2013, 9(1):93-102.")
	})
})