$(document).ready(function() {
	$("#page28_bg").css({
		"width": "1024px",
		"height": "748px",
		"background": "url(\'images/page28_bg.png\') no-repeat",
		"background-size": "1024px 748px"
	})

	$.getScript("js/common.js", function() {
		addComment("文献：<br/>23. Feng FY,et al.Int J Radiat Oncol Biol Phys.2013,86(1):64-71.")
	})
})