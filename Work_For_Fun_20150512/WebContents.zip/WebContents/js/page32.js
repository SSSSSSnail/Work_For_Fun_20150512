$(document).ready(function() {
	$("#page32_bg").css({
		"width": "1024px",
		"height": "748px",
		"background": "url(\'images/page32_bg.png\') no-repeat",
		"background-size": "1024px 748px"
	})

	$.getScript("js/common.js", function() {
		addComment("文献：<br/>11. Bolla M,et al. N Engl J Med.2009,360(24):2516-27.")
	})
})